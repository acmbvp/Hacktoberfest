//
//  DataMnager.swift
//  workFlowApp
//
//  Created by Intern on 10/06/19.
//  Copyright © 2019 Intern. All rights reserved.
//

import Foundation

class DataMnager {
    var dict = ["projectname":"", "startTime":"", "endTime":"" , "timeConsumed":"", "hourConsumed": 0, "minuteConsumed": 0] as [String : Any]
    var arrayInTable = [Dictionary<String, Any>]()
}
