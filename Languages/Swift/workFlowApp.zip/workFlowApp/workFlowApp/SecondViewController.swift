//
//  SecondViewController.swift
//  workFlowApp
//
//  Created by Intern on 06/06/19.
//  Copyright © 2019 Intern. All rights reserved.
//

import UIKit

protocol AllFieldPass: class {
    func passToMain(pname: String, sName: String, hours:Int, minute:Int, taskAccom:String)
}

enum SetTime {
    case hours
    case minutes
}

class SecondViewController: UIViewController {

    let dateFormatter = DateFormatter()
    var timePicker = UIPickerView()
    var timePicker2 = UIPickerView()
    var time: [SetTime] = [.hours,.minutes]
    var hourArray = ["1","2","3","4","5","6","7","8","9","10","11","12"]
    var minArray = ["0","15","30","45"]
    let toolBar = UIToolbar()
    
    @IBOutlet weak var projectNameLbl: UITextField!
    
    @IBOutlet weak var salesOrderLbl: UITextField!
    
    @IBOutlet weak var hourLbl: UITextField!
    
    @IBOutlet weak var minLbl: UITextField!
    
    @IBOutlet weak var taskAccomLbl: UITextField!
    
    weak var delegateSecond:AllFieldPass?
    
    var firstVc = ViewController()
    
    var saveBtn = UIBarButtonItem()
    override func viewDidLoad() {
        super.viewDidLoad()
        self.navigationItem.title = "Create TimeSheet"
        toolBar.barStyle = UIBarStyle.default
        toolBar.isTranslucent = true
        toolBar.tintColor = UIColor(red: 76/255, green: 217/255, blue: 100/255, alpha: 1)
        toolBar.sizeToFit()
        
        let doneButton = UIBarButtonItem(title: "Done", style: UIBarButtonItem.Style.plain, target: self, action: #selector(donePicker))
        toolBar.setItems([doneButton], animated: false)
        toolBar.isUserInteractionEnabled = true
        save()
    }
    
    func save()
    {
        saveBtn = UIBarButtonItem(title: "Save", style: .done, target: self, action: #selector(saveTask))
        saveBtn.title = "Save"
        self.navigationItem.rightBarButtonItem = saveBtn
    }
    
    @objc func saveTask() {
        let takeHour = Int(hourLbl.text!)
        let takeMin = Int(minLbl.text!)
        
        delegateSecond?.passToMain(pname: projectNameLbl.text!, sName: salesOrderLbl.text!, hours: takeHour!, minute: takeMin!, taskAccom: taskAccomLbl.text!)
        self.navigationController?.popViewController(animated: true)
    }
    
    
    @IBAction func takeProjectName(_ sender: Any) {
        
        let thirdVc = self.storyboard?.instantiateViewController(withIdentifier: "third") as? ThirdViewController
            thirdVc?.delegate = self
            self.navigationController?.pushViewController(thirdVc!, animated: true)
        self.view.endEditing(true)
    }
    
    @IBAction func hourPick(_ sender: Any) {
        self.timePicker = UIPickerView(frame: CGRect(x: 0, y: 0, width: self.view.frame.width, height: 216))
        self.timePicker.delegate = self
        self.timePicker.dataSource = self
        self.timePicker.backgroundColor = .white
        hourLbl.inputView = timePicker
        hourLbl.inputAccessoryView = toolBar
    }
    
    @objc func donePicker() {
        self.view.endEditing(true)
    }
    
    @IBAction func minutePick(_ sender: Any) {
        self.timePicker2 = UIPickerView(frame: CGRect(x: 0, y: 0, width: self.view.frame.width, height: 216))
        self.timePicker2.delegate = self
        self.timePicker2.dataSource = self
        self.timePicker2.backgroundColor = .white
        minLbl.inputView = timePicker2
         minLbl.inputAccessoryView = toolBar
    }
    
}

extension SecondViewController: DataPass {
    func takedata(name: String) {
        projectNameLbl.text = name
    }
}

extension SecondViewController: UIPickerViewDelegate, UIPickerViewDataSource {
    
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }
    
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        
        if pickerView == self.timePicker {
            return hourArray.count
        }
        else {
            return minArray.count
        }
    }
    
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        
        if pickerView == self.timePicker {
            return hourArray[row]
        }
        else {
            return minArray[row]
        }
    }
    
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        
        if pickerView == self.timePicker {
            hourLbl.text = hourArray[row]
        }
        else {
            minLbl.text = minArray[row]
        }
    }
    
}
