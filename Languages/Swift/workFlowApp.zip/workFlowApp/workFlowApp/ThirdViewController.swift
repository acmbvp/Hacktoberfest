//
//  ThirdViewController.swift
//  workFlowApp
//
//  Created by Intern on 06/06/19.
//  Copyright © 2019 Intern. All rights reserved.
//

import UIKit

protocol DataPass: class {
    func takedata(name:String)
}

class ThirdViewController: UIViewController {

    
    @IBOutlet weak var thirdTableView: UITableView!
    var projectName = ["First Project", "Second Project", "Third Project", "Fourth Project"]
    weak var delegate:DataPass?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.navigationItem.title = "Pick The Project name"
        thirdTableView.delegate = self
        thirdTableView.dataSource = self
    }

}

extension ThirdViewController: UITableViewDelegate, UITableViewDataSource {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 3
    }
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, titleForHeaderInSection section: Int) -> String? {
        return "Projects"
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        var cell = thirdTableView.dequeueReusableCell(withIdentifier: "cellIdentifier")
        
        if cell == nil {
            cell = UITableViewCell(style: .default, reuseIdentifier: "cellIdentifier")
        }
        
        cell?.textLabel?.text = projectName[indexPath.row]
        
        return cell!
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        let takeproject = projectName[indexPath.row]
        delegate?.takedata(name: takeproject)
        self.navigationController?.popViewController(animated: true)
        
    }
}
