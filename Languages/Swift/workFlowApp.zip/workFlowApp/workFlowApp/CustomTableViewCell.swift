//
//  CustomTableViewCell.swift
//  workFlowApp
//
//  Created by Intern on 06/06/19.
//  Copyright © 2019 Intern. All rights reserved.
//

import UIKit

class CustomTableViewCell: UITableViewCell {

    
    @IBOutlet weak var pName: UILabel!
    
    @IBOutlet weak var sTime: UILabel!
    
    @IBOutlet weak var timeConsumeLbl: UILabel!
    
    @IBOutlet weak var eTime: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

    }
    
}
