//
//  ViewController.swift
//  workFlowApp
//
//  Created by Intern on 06/06/19.
//  Copyright © 2019 Intern. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var firstTableView: UITableView!
    let toolBar = UIToolbar()
    
    var edititngBool:Bool = false
    var user:DataMnager = DataMnager()
    var dataCollected:Int?
    var flag1:Bool = false
    var flag2:Bool = true
    let dateFormatter = DateFormatter()
    var abc:String = ""
    var taskBtn = UIBarButtonItem()
    var editBtn = UIBarButtonItem()
    var firstLabel = UITextView()
    let textField = UITextField()
    override func viewDidLoad() {
        
        super.viewDidLoad()
        self.textField.text = "Set Time"
        self.navigationItem.titleView = textField
        task()
        edit()
        self.editBtn.isEnabled = false
        self.taskBtn.isEnabled = false
        firstTableView.delegate = self
        firstTableView.dataSource = self
        firstTableView.isEditing = false
        let headerNib = UINib(nibName: "CustomTableViewCell" ,bundle: nil)
        firstTableView.register(headerNib, forCellReuseIdentifier: "headernib")
        dataCollected = user.arrayInTable.count // Change
        firstTableView.isHidden = true
        toolBar.barStyle = UIBarStyle.default
        toolBar.isTranslucent = true
        toolBar.tintColor = UIColor(red: 76/255, green: 217/255, blue: 100/255, alpha: 1)
        toolBar.sizeToFit()
        
        let doneButton = UIBarButtonItem(title: "Done", style: UIBarButtonItem.Style.plain, target: self, action: #selector(donePicker))
        toolBar.setItems([doneButton], animated: false)
        toolBar.isUserInteractionEnabled = true
        pickdateopen()
        self.taskBtn.isEnabled = false
    }
    
    @objc func donePicker() {
        self.textField.isUserInteractionEnabled = false
        textField.resignFirstResponder()
        self.taskBtn.isEnabled = true
    }
    
    func task() {
        taskBtn = UIBarButtonItem(title: "Save", style: .done, target: self, action: #selector(creatTask))
        taskBtn.title = "+"
        self.navigationItem.rightBarButtonItem = taskBtn
    }
    
    func edit() {
        editBtn = UIBarButtonItem(title: "Edit", style: .done, target: self, action: #selector(editTask))
        editBtn.title = "Edit"
        self.navigationItem.leftBarButtonItem = editBtn
    }
    
    @objc func editTask() {
        self.edititngBool = true
        self.firstTableView.isEditing = true
    }
    
    @objc func creatTask() {
        
         if let secondVc = self.storyboard?.instantiateViewController(withIdentifier: "second") as? SecondViewController {
            secondVc.delegateSecond = self
            self.navigationController?.pushViewController(secondVc , animated: true)
        }
    }
    
    func pickdateopen() {
        let datePickerView:UIDatePicker = UIDatePicker()
        datePickerView.datePickerMode = UIDatePicker.Mode.time
        textField.inputView = datePickerView
        datePickerView.addTarget(self, action: #selector(datePickerFromValueChanged), for: UIControl.Event.valueChanged)
        textField.inputAccessoryView = toolBar
    }
    
    
    @objc func datePickerFromValueChanged(sender:UIDatePicker) {
    
        dateFormatter.dateFormat = "hh:mm a"
        textField.text = dateFormatter.string(from: sender.date)
        user.dict["startTime"] = dateFormatter.string(from: sender.date)
        dateFormatter.dateFormat = "hh:mm a"
        
        self.navigationItem.title = user.dict["startTime"] as! String
    self.taskBtn.isEnabled = true
    }
    
    func takeDate() -> Date {
            dateFormatter.dateFormat = "hh:mm a"
            let date = dateFormatter.date(from: user.dict["startTime"]! as! String)
            print(date!)
            return date!
        }
    
}

extension ViewController: AllFieldPass {
    func passToMain(pname: String, sName: String, hours: Int, minute: Int, taskAccom: String) {
        print(pname, sName, hours, minute, taskAccom)
        self.firstTableView.isEditing = false
        self.edititngBool = false
        dateFormatter.dateFormat = "hh:mm a"
        dateFormatter.timeZone = TimeZone.current
        user.dict["projectname"] = pname
        user.dict["hourConsumed"] = hours
        let h:Int = user.dict["hourConsumed"] as! Int
        user.dict["minuteConsumed"] = minute
        let m:Int = user.dict["minuteConsumed"] as! Int
        user.dict["timeConsumed"] = dateFormatter.string(from: takeDate().addingTimeInterval(TimeInterval(h*60*60+m*60)))
        let hours2 = dateFormatter.date(from: user.dict["startTime"]! as! String)
        dateFormatter.dateFormat = "hh"
        let inHours = dateFormatter.string(from: hours2!)
        print(inHours)
        dateFormatter.dateFormat = "a"
        let ptimeZone =  dateFormatter.string(from:  hours2!)
        print(ptimeZone)
        
        dateFormatter.dateFormat = "hh:mm a"
        let currentTimeZoneTake =  dateFormatter.date(from:  user.dict["timeConsumed"]! as! String)
        dateFormatter.dateFormat = "a"
        let ctimeZone = dateFormatter.string(from: currentTimeZoneTake!)
        
        
        if ptimeZone == "AM" || ptimeZone == "PM" {
            if Int(inHours)! + hours > 12 && flag2 {
                print(Int(inHours)! + hours)
                flag1 = true
            }
            else {
                flag1 = false
            }
            if ctimeZone == "PM" && flag1{
                print("Break")
                dateFormatter.dateFormat = "hh:mm a"
                dateFormatter.timeZone = TimeZone.current
                user.dict["timeConsumed"] = dateFormatter.string(from: takeDate().addingTimeInterval(TimeInterval((hours+1)*60*60+minute*60)))
                flag2 = false
            }
        }

        user.dict["endTime"] = "\(user.dict["hourConsumed"]!)" + "hours " + "\(user.dict["minuteConsumed"]!)" + "minutes"
        self.firstTableView.isHidden = false
        self.user.arrayInTable.append(user.dict)
        dataCollected = user.arrayInTable.count
        self.firstTableView.reloadData()
        user.dict["startTime"] = user.dict["timeConsumed"]
    }
    
}


extension ViewController: UITableViewDelegate, UITableViewDataSource {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if dataCollected ?? 0 > 1 {
            self.editBtn.isEnabled = true
        }
        return dataCollected ?? 0
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        guard let cell = tableView.dequeueReusableCell(withIdentifier: "headernib") as? CustomTableViewCell else {
            fatalError("Thumb Nail Table View Cell Not Found")
        }
        if edititngBool {
            
            
            
            // Change
            //var dictNotShown = user.arrayInTable[indexPath.row-1]
            if indexPath.row == 0{
                
                var dictShown = user.arrayInTable[indexPath.row]
                print(indexPath.row)
                //Do
                dateFormatter.dateFormat = "hh:mm a"
                dateFormatter.timeZone = TimeZone.current
                let h:Int = dictShown["hourConsumed"] as! Int
                let m:Int = dictShown["minuteConsumed"] as! Int
                dictShown["timeConsumed"] = dateFormatter.string(from: takeDate().addingTimeInterval(TimeInterval(h*60*60+m*60)))
                print(dictShown["timeConsumed"])
                let hours2 = dateFormatter.date(from: user.dict["startTime"]! as! String)
                dateFormatter.dateFormat = "hh"
                let inHours = dateFormatter.string(from: hours2!)
                print(inHours)
                dateFormatter.dateFormat = "a"
                let ptimeZone =  dateFormatter.string(from:  hours2!)
                print(ptimeZone)
                
                dateFormatter.dateFormat = "hh:mm a"
                let currentTimeZoneTake =  dateFormatter.date(from:  dictShown["timeConsumed"]! as! String)
                dateFormatter.dateFormat = "a"
                let ctimeZone = dateFormatter.string(from: currentTimeZoneTake!)
                
                
                if ptimeZone == "AM" || ptimeZone == "PM" {
                    if Int(inHours)! + h > 12 && flag2 {
                        print(Int(inHours)! + h)
                        flag1 = true
                    }
                    else {
                        flag1 = false
                    }
                    if ctimeZone == "PM" && flag1{
                        print("Break")
                        dateFormatter.dateFormat = "hh:mm a"
                        dateFormatter.timeZone = TimeZone.current
                        dictShown["timeConsumed"] = dateFormatter.string(from: takeDate().addingTimeInterval(TimeInterval((h+1)*60*60+m*60)))
                        flag2 = false
                    }
                }
                
                dictShown["endTime"] = "\(dictShown["hourConsumed"]!)" + "hours " + "\(dictShown["minuteConsumed"]!)" + "minutes"
                dictShown["startTime"] = dictShown["timeConsumed"]
                
                //Done
                
                cell.pName.text = dictShown["projectname"] as? String
                cell.sTime.text = dictShown["startTime"] as? String
                cell.eTime.text = dictShown["timeConsumed"] as? String
                cell.timeConsumeLbl.text = dictShown["endTime"] as? String
                cell.selectionStyle = .none
            } else {
                var dictNotShown = user.arrayInTable[indexPath.row-1]
                
                var dictShown = user.arrayInTable[indexPath.row]
                print(indexPath.row)
                //Do
                dateFormatter.dateFormat = "hh:mm a"
                dateFormatter.timeZone = TimeZone.current
                let h:Int = dictShown["hourConsumed"] as! Int
                let m:Int = dictShown["minuteConsumed"] as! Int
                dictShown["timeConsumed"] = dateFormatter.string(from: takeDate().addingTimeInterval(TimeInterval(h*60*60+m*60)))
                print(dictShown["timeConsumed"])
                let hours2 = dateFormatter.date(from: user.dict["startTime"]! as! String)
                dateFormatter.dateFormat = "hh"
                let inHours = dateFormatter.string(from: hours2!)
                print(inHours)
                dateFormatter.dateFormat = "a"
                let ptimeZone =  dateFormatter.string(from:  hours2!)
                print(ptimeZone)
                
                dateFormatter.dateFormat = "hh:mm a"
                let currentTimeZoneTake =  dateFormatter.date(from:  dictShown["timeConsumed"]! as! String)
                dateFormatter.dateFormat = "a"
                let ctimeZone = dateFormatter.string(from: currentTimeZoneTake!)
                
                
                if ptimeZone == "AM" || ptimeZone == "PM" {
                    if Int(inHours)! + h > 12 && flag2 {
                        print(Int(inHours)! + h)
                        flag1 = true
                    }
                    else {
                        flag1 = false
                    }
                    if ctimeZone == "PM" && flag1{
                        print("Break")
                        dateFormatter.dateFormat = "hh:mm a"
                        dateFormatter.timeZone = TimeZone.current
                        dictShown["timeConsumed"] = dateFormatter.string(from: takeDate().addingTimeInterval(TimeInterval((h+1)*60*60+m*60)))
                        flag2 = false
                    }
                }
                
                dictShown["endTime"] = "\(dictShown["hourConsumed"]!)" + "hours " + "\(dictShown["minuteConsumed"]!)" + "minutes"
                dictShown["startTime"] = dictShown["timeConsumed"]
                
                //Done
                
                cell.pName.text = dictShown["projectname"] as? String
                cell.sTime.text = dictNotShown["startTime"] as? String
                cell.eTime.text = dictShown["timeConsumed"] as? String
                cell.timeConsumeLbl.text = dictShown["endTime"] as? String
                cell.selectionStyle = .none
            }
            
            return cell
        } else {
            var dictShown = user.arrayInTable[indexPath.row] // Change
            cell.pName.text = dictShown["projectname"] as? String
            cell.sTime.text = dictShown["startTime"] as? String
            cell.eTime.text = dictShown["timeConsumed"] as? String
            cell.timeConsumeLbl.text = dictShown["endTime"] as? String
            cell.selectionStyle = .none
            return cell
        }
        
//        var dictShown = user.arrayInTable[indexPath.row] // Change
//        cell.pName.text = dictShown["projectname"] as? String
//        cell.sTime.text = dictShown["startTime"] as? String
//        cell.eTime.text = dictShown["timeConsumed"] as? String
//        cell.timeConsumeLbl.text = dictShown["endTime"] as? String
//        cell.selectionStyle = .none
//        return cell
        
    }
    
    func tableView(_ tableView: UITableView, editingStyleForRowAt indexPath: IndexPath) -> UITableViewCell.EditingStyle {
        return .none
    }

    func tableView(_ tableView: UITableView, shouldIndentWhileEditingRowAt indexPath: IndexPath) -> Bool {
        return false
    }


    func tableView(_ tableView: UITableView, moveRowAt sourceIndexPath: IndexPath, to destinationIndexPath: IndexPath) {


        let movedObject = self.user.arrayInTable[sourceIndexPath.row]
        print(movedObject)
        let movingObject = self.user.arrayInTable[destinationIndexPath.row]
        print(movingObject)
        user.arrayInTable.remove(at: sourceIndexPath.row)
        user.arrayInTable.insert(movedObject, at: destinationIndexPath.row)
        print("source index\(sourceIndexPath.row)")
        print("destination index \(destinationIndexPath.row)")

        self.firstTableView.reloadData()
    }
}
